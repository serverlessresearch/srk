def echo(event):
    return event
